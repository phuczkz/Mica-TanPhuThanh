import { useState, useEffect } from "react";
import { getCategories } from "../../services/categoryService";

export function CategorySection({ products }) {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const categoriesData = await getCategories();
        setCategories(categoriesData);
      } catch (error) {
        console.error("Error loading categories:", error);
      }
    };
    fetchCategories();
  }, []);

  // Group products by category
  const productsByCategory = {};
  products.forEach((product) => {
    const categoryId = product.category || "other";
    if (!productsByCategory[categoryId]) {
      productsByCategory[categoryId] = [];
    }
    productsByCategory[categoryId].push(product);
  });

  return (
    <div>
      {categories.map((category) => {
        const categoryProducts = productsByCategory[category.id];

        if (!categoryProducts || categoryProducts.length === 0) {
          return null;
        }

        return (
          <div key={category.id} className="category-section">
            <div className="category-header">
              <span className="category-icon">🏷️</span>
              <h2 className="category-title">{category.name}</h2>
            </div>

            <div className="products-grid">
              {categoryProducts.map((product) => (
                <div key={product.id} className="product-card">
                  {product.imageBase64 ? (
                    <img
                      src={product.imageBase64}
                      alt={product.name}
                      className="product-image"
                    />
                  ) : (
                    <div className="no-image">Không có ảnh</div>
                  )}
                  <div className="product-name">{product.name}</div>
                  <div className="product-price">
                    {product.price?.toLocaleString("vi-VN")} VND
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}
