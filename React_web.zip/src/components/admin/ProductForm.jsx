import { useState, useEffect } from "react";
import { getCategories } from "../../services/categoryService";
import { addProduct, updateProduct } from "../../services/productService";
import { compressImage } from "../../utils/imageUtils";

export function ProductForm({ productToEdit, onSave, onCancel }) {
  const [categories, setCategories] = useState([]);
  const [formData, setFormData] = useState({
    name: "",
    category: "",
    price: "",
    description: "",
    inStock: true,
    image: null,
    imagePreview: null,
  });
  const [loading, setLoading] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  useEffect(() => {
    const fetchCategories = async () => {
      const categoriesData = await getCategories();
      setCategories(categoriesData);
    };
    fetchCategories();
  }, []);

  useEffect(() => {
    if (productToEdit) {
      setFormData({
        name: productToEdit.name,
        category: productToEdit.category,
        price: productToEdit.price,
        description: productToEdit.description,
        inStock: productToEdit.inStock !== false,
        image: null,
        imagePreview: productToEdit.imageBase64,
      });
      setShowPreview(true);
    }
  }, [productToEdit]);

  // Update preview when form data changes
  useEffect(() => {
    if (
      formData.name ||
      formData.category ||
      formData.description ||
      formData.price ||
      formData.imagePreview
    ) {
      setShowPreview(true);
    } else {
      setShowPreview(false);
    }
  }, [formData]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleImageChange = async (e) => {
    const file = e.target.files[0];
    if (!file) {
      setFormData((prev) => ({
        ...prev,
        image: null,
        imagePreview: null,
      }));
      return;
    }

    // Validate file size (5MB max)
    if (file.size > 5 * 1024 * 1024) {
      alert("Ảnh quá lớn! Vui lòng chọn ảnh nhỏ hơn 5MB.");
      e.target.value = "";
      return;
    }

    try {
      const compressedImage = await compressImage(file, 600, 0.7);

      // Check compressed size
      const sizeInBytes = compressedImage.length * 0.75;
      if (sizeInBytes > 1000000) {
        alert("Ảnh vẫn quá lớn sau khi nén. Vui lòng chọn ảnh nhỏ hơn.");
        e.target.value = "";
        return;
      }

      setFormData((prev) => ({
        ...prev,
        image: file,
        imagePreview: compressedImage,
      }));
    } catch (error) {
      console.error("Image processing error:", error);
      alert("Có lỗi khi xử lý ảnh. Vui lòng thử lại.");
    }
  };

  const removeImage = () => {
    setFormData((prev) => ({
      ...prev,
      image: null,
      imagePreview: null,
    }));
    // Clear file input
    const fileInput = document.getElementById("productImage");
    if (fileInput) fileInput.value = "";
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validation
    if (!formData.name.trim()) {
      alert("Vui lòng nhập tên sản phẩm!");
      return;
    }
    if (!formData.category) {
      alert("Vui lòng chọn danh mục!");
      return;
    }
    if (!formData.price || formData.price <= 0) {
      alert("Vui lòng nhập giá hợp lệ!");
      return;
    }

    setLoading(true);
    try {
      const productData = {
        name: formData.name.trim(),
        category: formData.category,
        description: formData.description.trim(),
        price: parseInt(formData.price),
        inStock: formData.inStock,
        imageBase64: formData.imagePreview,
        imageType: "image/jpeg",
        updatedAt: new Date(),
      };

      if (!productToEdit) {
        productData.createdAt = new Date();
      }

      if (productToEdit) {
        await updateProduct(productToEdit.id, productData);
        alert("✅ Sản phẩm đã được cập nhật thành công!");
      } else {
        await addProduct(productData);
        alert("✅ Sản phẩm đã được thêm thành công!");
      }

      onSave();
      resetForm();
    } catch (error) {
      console.error("Error saving product:", error);
      alert("Có lỗi khi lưu sản phẩm: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      category: "",
      price: "",
      description: "",
      inStock: true,
      image: null,
      imagePreview: null,
    });
    setShowPreview(false);

    // Clear file input
    const fileInput = document.getElementById("productImage");
    if (fileInput) fileInput.value = "";
  };

  const getCategoryName = (categoryId) => {
    const category = categories.find((cat) => cat.id === categoryId);
    return category ? category.name : categoryId;
  };

  return (
    <div className="form-card">
      <h3 className="form-title">
        {productToEdit ? "✏️ Chỉnh sửa sản phẩm" : "➕ Thêm sản phẩm mới"}
      </h3>

      <form onSubmit={handleSubmit}>
        <div className="form-row">
          <div className="form-group">
            <label>Tên sản phẩm *</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              className="form-control"
              placeholder="Nhập tên sản phẩm"
              required
            />
          </div>

          <div className="form-group">
            <label>Danh mục *</label>
            <select
              name="category"
              value={formData.category}
              onChange={handleChange}
              className="form-control"
              required
            >
              <option value="">Chọn danh mục</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>Giá (VND) *</label>
            <input
              type="number"
              name="price"
              value={formData.price}
              onChange={handleChange}
              className="form-control"
              placeholder="Nhập giá sản phẩm"
              min="0"
              required
            />
          </div>

          <div className="form-group">
            <label>Tình trạng kho</label>
            <div className="checkbox-group">
              <input
                type="checkbox"
                id="inStock"
                name="inStock"
                checked={formData.inStock}
                onChange={handleChange}
              />
              <label htmlFor="inStock">Còn hàng</label>
            </div>
          </div>
        </div>

        <div className="form-group form-row-full">
          <label>Mô tả sản phẩm</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            className="form-control"
            placeholder="Mô tả chi tiết sản phẩm..."
            rows="4"
          />
        </div>

        <div className="form-group form-row-full">
          <label>Ảnh sản phẩm</label>
          <div className="file-input">
            <input
              type="file"
              id="productImage"
              accept="image/*"
              onChange={handleImageChange}
            />
            <label htmlFor="productImage" className="file-input-label">
              {formData.image ? formData.image.name : "Chọn ảnh sản phẩm"}
            </label>
          </div>
        </div>

        {formData.imagePreview && (
          <div className="image-preview">
            <img src={formData.imagePreview} alt="Preview" />
            <button
              type="button"
              onClick={removeImage}
              className="btn btn-danger btn-sm"
            >
              Xóa ảnh
            </button>
          </div>
        )}

        {/* Product Preview */}
        {showPreview && (
          <div className="preview-section">
            <h4>👁️ Xem trước sản phẩm:</h4>
            <div className="preview-product">
              {formData.imagePreview ? (
                <img
                  src={formData.imagePreview}
                  alt="Preview"
                  style={{
                    width: "100%",
                    height: "150px",
                    objectFit: "cover",
                    borderRadius: "8px",
                    marginBottom: "15px",
                  }}
                />
              ) : (
                <div
                  className="no-image"
                  style={{ height: "150px", marginBottom: "15px" }}
                >
                  Không có ảnh
                </div>
              )}

              {formData.category && (
                <div className="product-category">
                  {getCategoryName(formData.category)}
                </div>
              )}

              <div className="product-name">
                {formData.name || "Tên sản phẩm"}
              </div>

              {formData.description && (
                <div className="product-description">
                  {formData.description}
                </div>
              )}

              <div className="product-price">
                {formData.price
                  ? parseInt(formData.price).toLocaleString("vi-VN") + " VND"
                  : "Giá sản phẩm"}
              </div>

              <div
                className={`product-stock ${
                  formData.inStock ? "in-stock" : "out-of-stock"
                }`}
              >
                {formData.inStock ? "✅ Còn hàng" : "❌ Hết hàng"}
              </div>
            </div>
          </div>
        )}

        <div className="form-actions">
          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading
              ? "Đang lưu..."
              : productToEdit
              ? "Cập nhật sản phẩm"
              : "Thêm sản phẩm"}
          </button>

          {productToEdit && (
            <button
              type="button"
              onClick={onCancel}
              className="btn btn-secondary"
            >
              Hủy chỉnh sửa
            </button>
          )}

          <button
            type="button"
            onClick={resetForm}
            className="btn btn-secondary"
          >
            Làm mới form
          </button>
        </div>
      </form>
    </div>
  );
}
