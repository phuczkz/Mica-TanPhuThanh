import { useState, useEffect } from "react";
import {
  getCategories,
  addCategory,
  deleteCategory,
} from "../../services/categoryService";
import { useAuth } from "../../context/AuthContext";

export function CategoryManager() {
  const [categories, setCategories] = useState([]);
  const [newCategoryName, setNewCategoryName] = useState("");
  const [loading, setLoading] = useState(false);
  const { currentUser } = useAuth();

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    try {
      const categoriesData = await getCategories();
      setCategories(categoriesData);
    } catch (error) {
      console.error("Error loading categories:", error);
    }
  };

  const handleAddCategory = async () => {
    if (!newCategoryName.trim()) {
      alert("Vui lòng nhập tên danh mục!");
      return;
    }

    if (
      categories.find(
        (cat) => cat.name.toLowerCase() === newCategoryName.toLowerCase()
      )
    ) {
      alert("Danh mục này đã tồn tại!");
      return;
    }

    setLoading(true);
    try {
      const categoryData = {
        name: newCategoryName,
        isDefault: false,
        createdAt: new Date(),
        createdBy: currentUser.email,
      };

      const newCategoryDocId = await addCategory(categoryData);
      const newCategory = {
        id: newCategoryDocId,
        ...categoryData,
      };

      setCategories((prevCategories) => [...prevCategories, newCategory]);
      setNewCategoryName("");
      alert("✅ Danh mục đã được thêm thành công!");
    } catch (error) {
      alert("❌ Lỗi khi thêm danh mục: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteCategory = async (categoryId) => {
    if (!window.confirm("Bạn có chắc chắn muốn xóa danh mục này?")) {
      return;
    }

    try {
      await deleteCategory(categoryId);
      setCategories((prevCategories) =>
        prevCategories.filter((category) => category.id !== categoryId)
      );
      alert("✅ Danh mục đã được xóa thành công!");
    } catch (error) {
      alert("❌ Lỗi khi xóa danh mục: " + error.message);
    }
  };

  return (
    <div className="form-card">
      <h3 className="form-title">🏷️ Quản lý danh mục</h3>

      <div className="form-group">
        <label>Thêm danh mục mới</label>
        <div className="category-input-group">
          <input
            type="text"
            value={newCategoryName}
            onChange={(e) => setNewCategoryName(e.target.value)}
            className="form-control"
            placeholder="Nhập tên danh mục..."
            onKeyPress={(e) => e.key === "Enter" && handleAddCategory()}
          />
          <button
            onClick={handleAddCategory}
            className="btn btn-success"
            disabled={loading}
          >
            {loading ? "Đang thêm..." : "Thêm"}
          </button>
        </div>
      </div>

      <div className="form-group">
        <label>
          Danh sách danh mục hiện tại ({categories.length} danh mục)
        </label>
        <div className="category-list">
          {categories.map((category) => (
            <div key={category.id} className="category-item">
              <span className="category-name">{category.name}</span>
              {!category.isDefault ? (
                <button
                  onClick={() => handleDeleteCategory(category.id)}
                  className="btn-delete-category"
                >
                  Xóa
                </button>
              ) : (
                <span style={{ fontSize: "12px", color: "#6c757d" }}>
                  Mặc định
                </span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
