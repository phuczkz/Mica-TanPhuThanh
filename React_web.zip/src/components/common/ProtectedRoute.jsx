import { Navigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

const AUTHORIZED_EMAILS = ["pt74009@gmail.com"]; // Thay bằng email admin thực tế

export function ProtectedRoute({ children, adminOnly = false }) {
  const { currentUser } = useAuth();

  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }

  if (adminOnly && !AUTHORIZED_EMAILS.includes(currentUser.email)) {
    return <Navigate to="/" replace />;
  }

  return children;
}
