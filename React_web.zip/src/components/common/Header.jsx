import { useState } from "react";
import { Search, ShoppingCart, Phone, Menu, User, MapPin } from "lucide-react";
import "../../styles/Header.css"; // Ensure you have the correct path to your CSS file

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  const handleSearch = (e) => {
    e.preventDefault();
    // Xử lý tìm kiếm
    console.log("Searching for:", searchTerm);
  };

  return (
    <header className="main-header">
      {/* Top Bar */}
      <div className="top-bar">
        <div className="container">
          <div className="contact-info">
            <div className="hotline-info">
              <Phone className="phone-icon" size={16} />
              <span className="hotline-label">Hotline:</span>
              <a href="tel:0656789456" className="hotline-number">
                0656.789.456
              </a>
              <span className="support-text">Hỗ trợ 24/7</span>
            </div>
          </div>

          <div className="header-actions">
            <div className="location-info">
              <MapPin size={14} />
              <span>Hồ Chí Minh</span>
            </div>

            <div className="cart-info">
              <span className="cart-total">1.001.230 đ</span>
              <ShoppingCart size={18} />
              <span className="cart-count">3</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="header-main">
        <div className="container">
          <div className="header-content">
            {/* Logo */}
            <div className="logo">
              <h1 className="logo-text">SiVi SHOP</h1>
            </div>

            {/* Navigation Menu */}
            <nav className="main-nav">
              <button
                className="mobile-menu-toggle"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                <Menu size={24} />
              </button>

              <ul className={`nav-menu ${isMenuOpen ? "nav-menu-open" : ""}`}>
                <li className="nav-item">
                  <a href="/" className="nav-link active">
                    TRANG CHỦ
                  </a>
                </li>
                <li className="nav-item">
                  <a href="#" className="nav-link">
                    CỬA HÀNG
                  </a>
                </li>
                <li className="nav-item dropdown">
                  <a href="#" className="nav-link">
                    SẢN PHẨM <span className="dropdown-arrow">▼</span>
                  </a>
                  <ul className="dropdown-menu">
                    <li>
                      <a href="#">🥩 Thịt tươi</a>
                    </li>
                    <li>
                      <a href="#">🥬 Rau củ</a>
                    </li>
                    <li>
                      <a href="#">🍎 Trái cây</a>
                    </li>
                    <li>
                      <a href="#">🦐 Hải sản</a>
                    </li>
                    <li>
                      <a href="#">🥛 Sữa & đồ uống</a>
                    </li>
                  </ul>
                </li>
                <li className="nav-item">
                  <a href="#" className="nav-link">
                    BÀI VIẾT
                  </a>
                </li>
                <li className="nav-item">
                  <a href="#" className="nav-link">
                    LIÊN HỆ
                  </a>
                </li>
              </ul>
            </nav>

            {/* Search Section */}
            <div className="search-section">
              <form className="search-form" onSubmit={handleSearch}>
                <input
                  type="text"
                  className="search-input"
                  placeholder="Bạn đang tìm gì?"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <button type="submit" className="search-btn">
                  <Search size={18} />
                </button>
              </form>
            </div>

            {/* Admin Login */}
            <div className="admin-section">
              <a href="/login" className="admin-login-btn">
                <User size={16} />
                Admin
              </a>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
