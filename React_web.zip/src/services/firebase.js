import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth, GoogleAuthProvider } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyCQlAwJqPSL1aGR88ssu4U7cPIocsAB1-4",
  authDomain: "mica-d0e1c.firebaseapp.com",
  projectId: "mica-d0e1c",
  storageBucket: "mica-d0e1c.firebasestorage.app",
  messagingSenderId: "754278057177",
  appId: "1:754278057177:web:637144243cbd5922e0aac8",
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();

export { db, auth, provider };
