import { signInWithPopup, GoogleAuthProvider } from "firebase/auth";
import { auth } from "../services/firebase";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import "../styles/Admin.css";

export function LoginPage() {
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleGoogleLogin = async () => {
    setLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const user = result.user;

      console.log("Đăng nhập thành công:", user.email);

      // Chuyển hướng đến trang admin
      navigate("/admin");
    } catch (error) {
      console.error("Lỗi đăng nhập:", error);
      alert("Lỗi đăng nhập: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <h2 style={{ marginBottom: "20px", color: "#333" }}>
          🔐 Đăng nhập Admin
        </h2>
        <p style={{ color: "#666", marginBottom: "30px" }}>
          Sử dụng tài khoản Google để đăng nhập
        </p>

        <button
          onClick={handleGoogleLogin}
          className="google-btn"
          disabled={loading}
        >
          {loading ? "Đang đăng nhập..." : <>📧 Đăng nhập bằng Google</>}
        </button>

        <div style={{ marginTop: "20px" }}>
          <a
            href="/"
            style={{
              color: "#667eea",
              textDecoration: "none",
              fontSize: "14px",
            }}
          >
            ← Quay lại trang chủ
          </a>
        </div>
      </div>
    </div>
  );
}
