import { useState } from "react"; // Xóa useEffect
import { useAuth } from "../context/AuthContext";
import { CategoryManager } from "../components/admin/CategoryManager";
import { ProductForm } from "../components/admin/ProductForm";
import { ProductList } from "../components/admin/ProductList";
import AdminNavbar from "../components/admin/AdminNavbar";
import "../styles/Admin.css";

export function AdminPage() {
  const { currentUser, logout } = useAuth();
  const [activeTab, setActiveTab] = useState("products");
  const [productToEdit, setProductToEdit] = useState(null);

  if (!currentUser) {
    return null;
  }

  const handleEditProduct = (product) => {
    setProductToEdit(product);
    setActiveTab("products");

    setTimeout(() => {
      const formElement = document.querySelector(".form-card");
      if (formElement) {
        formElement.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }
    }, 100);
  };

  const handleSaveProduct = () => {
    setProductToEdit(null);
  };

  const handleCancelEdit = () => {
    setProductToEdit(null);
  };

  const handleTabChange = (newTab) => {
    if (newTab !== "products") {
      setProductToEdit(null);
    }
    setActiveTab(newTab);
  };

  return (
    <div className="admin-layout">
      <AdminNavbar
        activeTab={activeTab}
        setActiveTab={handleTabChange}
        user={currentUser}
        logout={logout}
      />

      <div className="main-content">
        <div className="page-header">
          <h1 className="page-title">
            {activeTab === "products" && "📦 Quản lý sản phẩm"}
            {activeTab === "categories" && "🏷️ Quản lý danh mục"}
          </h1>

          {productToEdit && activeTab === "products" && (
            <div className="edit-mode-banner">
              <span>
                ✏️ Đang chỉnh sửa: <strong>{productToEdit.name}</strong>
              </span>
              <button
                onClick={handleCancelEdit}
                className="btn btn-secondary btn-sm"
              >
                Hủy chỉnh sửa
              </button>
            </div>
          )}
        </div>

        {activeTab === "products" && (
          <>
            <ProductForm
              productToEdit={productToEdit}
              onSave={handleSaveProduct}
              onCancel={handleCancelEdit}
            />
            <ProductList onEdit={handleEditProduct} />
          </>
        )}

        {activeTab === "categories" && <CategoryManager />}
      </div>
    </div>
  );
}
